package com.patternsoft.quizduo.View;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.patternsoft.quizduo.R;

public class MainActivity extends AppCompatActivity {

    TextView signin,signup;
    RelativeLayout loginRV, registrationRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();


    }


    private void initViews(){
        signin=findViewById(R.id.login);
        signup=findViewById(R.id.signUp);
        registrationRV=findViewById(R.id.signUpView);
        loginRV=findViewById(R.id.loginView);


    }

    public void clicked(View view) {
        int id=view.getId();
        switch (id)
        {
            case R.id.login:
                displayRV(loginRV,registrationRV,signin,signup);
                break;
            case R.id.signUp:
                displayRV(registrationRV,loginRV,signup,signin);
                break;

        }
    }

    private void displayRV(RelativeLayout show, RelativeLayout hide, TextView colored, TextView nonColored) {

        show.setVisibility(View.VISIBLE);
        show.animate().translationY(0).setDuration(1500);

        hide.setVisibility(View.GONE);
        hide.animate().translationY(hide.getHeight());

        colored.setTextColor(getResources().getColor(R.color.mainColorText));
        colored.animate().alpha(1.0f).setDuration(3000);

        nonColored.setTextColor(getResources().getColor(R.color.grayText));

    }

}
